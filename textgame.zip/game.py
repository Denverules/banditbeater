import random
import pygame as pg
import os
import sys
if getattr(sys, 'frozen', False):
    os.chdir(sys._MEIPASS)
elements = ['fire', 'water','earth','ice','air'
            ]
robbed=0
pg.init()
stats={'max health':0,'speed':0,'defense':0,'sword skill':0,'element skill':0,'intelligence':0,'coins':0,'element':'none'}
screen = pg.display.set_mode((1920, 1080))
clock = pg.time.Clock()
running = True
screen.fill("black")
sword='stick'
armor='cloth'
banditdefeated=0
strengths={'water':['fire','earth'],'earth':['fire','air'],'ice':['water','earth'],'air':['water','ice'],
           'fire':['ice','air']}
objects={'wooden':False,'stone':False,'long':False,
        'leather':False,'chain':False,'iron':False}
healthbars=[]
for i in range(11):
    j=i*10
    ani=str(j)+'.png'
    healthbars.append(pg.image.load(os.path.join('images/healthbar', ani)))
images=[]
imagename=['hunt','jungle','shop','statistics','village','bandit','shopbg'
            ,'yes','no','train','quit','trainingground','back','health'
            ,'speed','def','sword','element','intelli','leatherarmor','chain armor'
            ,'ironarmor','woodsword','stonesword','longsword','character','contin']
imgpath='images/'
for i in imagename:
    image=i+'.png'
    images.append(pg.image.load(os.path.join(imgpath,image)))
rectangle = pg.Rect(0,0,90,90)
background=pg.Surface
empty=pg.Color(0,0,0,0)
prices={'wooden':100,'stone':200,'long':300,
        'leather':100,'chain':200,'iron':300}
def training(stat):
    global stats
    maxi=False
    for i in stats.keys():
        if i == stat and stat!='max health' and stat!='intelligence':
            increase = random.randint(5, 10)
            if stats[i] + increase>=100:
                stats[i]=100
                maxi = True
            else:
                stats[i]+=increase
        elif stat=='max health' and i== stat:
            increase = random.randint(20, 30)
            if stats[i] + increase >= 500:
                stats[i] = 500
                maxi=True
            else:
                stats[i] += increase
        elif stat=='intelligence' and i == stat:
            increase = random.randint(10, 20)
            if stats[i] + increase >= 200:
                stats[i] = 200
                maxi = True
            else:
                stats[i] += increase
    click=False
    while not click:
        screen.blit(images[3],(900,600))
        if not maxi:
            pygameprint('Training Successful',915,700,38)
        else:
            pygameprint('Stat is now max',915,700,38)
        for event in pg.event.get():
            if event.type==pg.MOUSEBUTTONDOWN:
                click = True

def train():
    global position
    screen.blit(images[11],(0,0))
    screen.blit(images[12],(200,850))

    ys=200
    for i in range(13,19):
        x=200

        screen.blit(images[i],(x,ys))
        ys += 100
    x=211
    while position=='train':
        ui()
        maxx=460
        for event in pg.event.get():
            mx,my=pg.mouse.get_pos()
            if event.type==pg.MOUSEBUTTONDOWN:
                if x<=mx<=maxx and 210<=my<=259:
                    training('max health')
                elif x<=mx<=maxx and 310<=my<=386:
                    training('speed')
                elif x<=mx<=maxx and 409<=my<=453:
                    training('defense')
                elif x<=mx<=maxx and 510<=my<=589 :
                    training('sword skill')
                elif x<=mx<=maxx and 613<=my<=692:
                    training('element skill')
                elif x<=mx<=maxx and 710<=my<=786:
                    training('intelligence')
                elif x<=mx<=maxx and 860<=my<=940:
                    position='village'
        pg.display.flip()
        screen.blit(images[11], (0, 0))
        screen.blit(images[12], (200, 850))
        screen.blit(images[25], (900, 200))
        ys = 200
        for i in range(13, 19):
            x = 200

            screen.blit(images[i], (x, ys))
            ys += 100

def healthcheck(h):
    if h <=0:
        h=0
    else:
        h=h
    return h


def buy(item):
    global stats,objects
    click=False
    while not click:
            for event in pg.event.get():
                if event.type == pg.MOUSEBUTTONDOWN:
                    click = True
            for i in list(prices):
                if i ==item:
                    if prices[item]>stats['coins']:
                        screen.blit(images[3],(900,700))
                        screen.blit(images[8], (1190, 675))
                        pygameprint('you do not have the funds',920,800,24)

                    else:
                        stats['coins']-=prices[item]
                        screen.blit(images[3], (900, 700))
                        screen.blit(images[8], (1190, 675))
                        pygameprint('purchase successful', 920, 800, 24)
                        objects[item]=True

def shop():
    global position
    while position =='shop':
        itemcoords = {}
        pg.display.flip()
        screen.fill(empty)
        screen.blit(images[6],(0,0))
        screen.blit(images[12], (200, 850))
        xs=300
        ys=300
        objectpres=list(objects.keys())
        xa=300

        for i in range(6):
            j=i+19
            if not objects[objectpres[i]]:
                screen.blit(images[j],(xs,ys))
                itemcoords[objectpres[i]]=[xs,ys,xs+200,ys+200]
                xs += 200
        for event in pg.event.get():

            if event.type==pg.MOUSEBUTTONDOWN:
                mx, my = pg.mouse.get_pos()
                if 211 <= mx <= 460 and 860 <= my <= 940:
                    position = 'village'
                for g in list(itemcoords.keys()):
                    coords=list(itemcoords[g])
                    lx,ly,hx,hy=coords
                    if lx<=mx<=hx and ly<=my<=hy:
                        buy(g)



def pygameprint(text,xpos,ypos,size,color='white'):
    fonts=pg.font.Font('C:/Windows/Fonts/segoeui.ttf', size)
    output=fonts.render(text,True,color)
    OUTPUTRECT=output.get_rect()
    OUTPUTRECT.x=xpos
    OUTPUTRECT.y=ypos
    screen.blit(output,OUTPUTRECT)
    pg.display.flip()


def ui():
    x=950
    y = 80
    pg.display.flip()
    screen.blit(images[3],(1350,100))
    statkeys = list(stats.keys())
    statvalues = list(stats.values())
    for i in range(8):
        outputstats = ''
        outputstats += str(statkeys[i]) + ':'
        outputstats += str(statvalues[i])
        font = pg.font.Font('fonts/segoeui.ttf', 32)
        text = font.render(outputstats, True, 'white', )
        textRect = text.get_rect()
        textRect.x = 1400
        y+=27.5
        textRect.y = y
        screen.blit(text,textRect)
def hunt():
    global enemy,difficulty,stats,robbed,banditdefeated
    screen.blit(images[5],(1200,250))
    pg.display.flip()

    armors = {'cloth':0,'leather':5,'chain':15,'iron':20}
    swords = {'stick':0,'wooden':5,'stone':15,'longsword':20}
    for i in swords:
        if i == sword:
            stats['sword skill'] += swords.get(i)
    for j in armors:
        if j == armor:
            stats['defense'] += armors.get(j)
    if banditdefeated< 10:
        difficult()
        banditgen(difficulty)
        fight()


    else:
        click =False
        while not click:
            for event.type in pg.event.get():
                if event.type == pg.MOUSEBUTTONDOWN:
                    click = True
            pygameprint('you are going to fight the boss bandit', 500, 500, 40)
            screen.blit(images[3],(450,450))
            enemy = Bandit()
            enemy.health = 700
            enemy.speed = 40
            enemy.element = random.choice(elements)
            enemy.defense = 70
            enemy.sword = 90
            enemy.elementskill = 90
            enemy.drops = 1000
        fight()

def healthdisplay(heal,totalheal,posx,posy):
    for i in range(11):
        healper = heal/totalheal * 100
        healper=healper//10
        if i == healper:
            screen.blit(healthbars[i],(posx,posy))
def village():
    screen.fill(empty)
    screen.blit(images[4],(0,0))
    screen.blit(images[0], (300, 800))
    screen.blit(images[2], (600, 805))
    screen.blit(images[9],(900,805))
    screen.blit(images[10],(1200,805))
def jungle():
    screen.blit(images[1], (0, 0))
    pg.display.flip()
    global won,position,y
    y=10
    hunt()
    screen.fill(empty)
    ui()
    screen.fill(empty)
    screen.blit(images[1], (0, 0))
    screen.blit(images[3], (750, 400))
    while position=='jungle':
        if robbed>=3:
            position='village'
            break
        ui()
        screen.blit(images[1], (0, 0))
        screen.blit(images[3], (750, 400))

        if boss:
            position='village'
        if won:

            screen.blit(images[3], (750, 400))
            textp='you won '+str(enemy.drops)+' coins.'
            pygameprint(textp,800,410,35)
            pygameprint('would you like  ',800,460,40)
            pygameprint('to hunt again',800,510,40)
            screen.blit(images[7],(950,650))
            screen.blit(images[8], (800,650))
        else:
            screen.blit(images[3], (750, 400))
            pygameprint('you lost click on the x to ',800,410,30)
            pygameprint(' return to village', 800, 440, 30)
            screen.blit(images[7], (950, 650))
            screen.blit(images[8], (800, 650))
        for event in pg.event.get():
            mx,my= pg.mouse.get_pos()
            if event.type== pg.MOUSEBUTTONDOWN and 652<=mx<=859 and 661<=my<=745:
                position='village'
            elif event.type==pg.MOUSEBUTTONDOWN and 962<=mx<=1173 and 665<=my<=744:
                screen.fill(empty)
                screen.blit(images[1],(0,0))
                hunt()
        pg.display.flip()
def banditgen(diff):
    global enemy
    if diff == 0:
        enemy = Bandit()
        enemy.health = random.randint(50,100)
        enemy.speed = random.randint(5,15)
        enemy.element = random.choice(elements)
        enemy.defense = random.randint(5,10)
        enemy.sword = random.randint(5,15)
        enemy.elementskill = random.randint(5,15)
        enemy.drops = random.randint(10, 50)
    elif diff == 1:
        enemy = Bandit
        enemy.health = random.randint(80, 120)
        enemy.speed = random.randint(20, 30)
        enemy.element = random.choice(elements)
        enemy.defense = random.randint(20, 25)
        enemy.sword = random.randint(20, 30)
        enemy.elementskill = random.randint(20, 30)
        enemy.drops = random.randint(60, 100)
    elif diff == 2:
        enemy = Bandit
        enemy.health = random.randint(180, 220)
        enemy.speed = random.randint(35, 35)
        enemy.element = random.choice(elements)
        enemy.defense = random.randint(35, 40)
        enemy.sword = random.randint(35, 40)
        enemy.elementskill = random.randint(35, 45)
        enemy.drops = random.randint(80, 150)
    elif diff == 3:
        enemy = Bandit
        enemy.health = random.randint(220, 260)
        enemy.speed = random.randint(45,55)
        enemy.element = random.choice(elements)
        enemy.defense = random.randint(45, 55)
        enemy.sword = random.randint(45, 55)
        enemy.elementskill = random.randint(45, 55)
        enemy.drops = random.randint(120, 200)
    elif diff == 4:
        enemy = Bandit
        enemy.health = random.randint(250, 290)
        enemy.speed = random.randint(55, 75)
        enemy.element = random.choice(elements)
        enemy.defense = random.randint(55, 65)
        enemy.sword = random.randint(55, 80)
        enemy.elementskill = random.randint(50, 90)
        enemy.drops = random.randint(190, 230)
def difficult():
    global difficulty
    total = 0
    for x in stats:
        if x != 'element':
            total+=stats[x]
    average=(total/100)-1
    if average>4:
        average=4
    if average<0:
        average=0
    for y in range(4):
        if average ==y:
            difficulty=average


def effectivecheck():
    global y,effective
    if effective == 1:
        y+=20
        pygameprint('attack was super effective',900,ypos=y,size=20)
    elif effective == 2:
        y+=20
        pygameprint('attack was not very effective',900,ypos=y,size=20)
difficulty=0
effective=0
def attack(swords,elementsk,defstat,elementatk,elementdf,damage=1):
    global x,y,effective
    effective=0
    df=1
    atk=1
    for i in strengths:
        if elementatk==i:
            strenlist = list(strengths[i])
            if elementdf in strenlist:
                atk = 2
            elif elementatk== elementdf:
                atk = 1
            else:
                atk=0
    damage += swords + elementsk /2
    if damage - (defstat/2) > 0:
        damage -= defstat/2
    else:
        damage = 1
    if atk> df:
        damage *= 1.25
        effective = 1
    elif df>atk:
        damage *=0.75
        effective = 2
    return(damage)
won=False

def fight():
    global stats,robbed,banditdefeated,boss,enemy,won,y,position,runn

    health = stats['max health']
    round=1
    y=200
    enemyheal=enemy.health
    runn=False
    while (enemyheal>0 and health >0) or not runn:
            screen.fill(empty)
            y = 200
            screen.blit(images[1], (0, 0))
            screen.blit(images[5], (1200, 250))
            screen.blit(images[25],(200,300))
            healthdisplay(health, stats['max health'], 200, 100)
            textp = 'the bandits element is ' + str(enemy.element)
            healthdisplay(enemyheal, enemy.health, 1300, 100)
            textc='Round '+str(round)
            pygameprint(textc,600,150,size=40)
            pygameprint(textp, 600, ypos=y, size=40)
            if enemy.speed> stats['speed']:
                damagedone=attack(enemy.sword,enemy.elementskill,stats['defense'],enemy.element,stats['element'])
                health -= damagedone
                health=healthcheck(health)

                if health>0:
                    damagedone = attack(stats['sword skill'],stats['element skill'],enemy.defense,stats['element'],enemy.element)
                    enemyheal-=damagedone
                    enemyheal=healthcheck(enemyheal)

            else:
                damagedone = attack(stats['sword skill'], stats['element skill'], enemy.defense, stats['element'], enemy.element)
                enemyheal-= damagedone
                enemyheal=healthcheck(enemyheal)
                if enemyheal>0:
                    damagedone = attack(enemy.sword, enemy.elementskill, stats['defense'], enemy.element, stats['element'])
                    health -= damagedone
                    health = healthcheck(health)

            if health <= 0:
                won=False
                stats['coins'] = stats['coins'] // 2
                robbed+=1
                runn=True

            if enemyheal <= 0 and banditdefeated<10:
                won=True
                stats['coins'] += enemy.drops
                banditdefeated+=1
                runn=True

            elif enemyheal <= 0 and banditdefeated>=10:
                boss = True
                won=True
                runn = True
                break

            click=False
            while not click:
                screen.blit(images[26],(900,400))
                screen.blit(images[7],(900,650))
                screen.blit(images[8],(1150,650))
                for event in pg.event.get():
                    mx, my = pg.mouse.get_pos()
                    if event.type== pg.MOUSEBUTTONDOWN:
                        if 900<=mx<=970 and 650<=my<=724:
                            click = True
                        elif 1150<=mx<=1224 and 650<=my<=720:
                            runn = run()
                            if runn:
                                position='village'
                            click=True
                pg.display.flip()
            round+=1

position='village'
def run():
    coin =random.randint(1,2)
    if coin==1:
        return True
    else:
        return False
def statgen():
    global stats,difficulty
    difficulty = random.randint(0,4)
    if difficulty == 0:
        stats['max health'] = 100
        stats['speed'] = 10
        stats['defense'] = 10
        stats['sword skill'] = 10
        stats['element skill'] = 10
        stats['intelligence'] = 40
    elif difficulty == 1:
        stats['max health'] = 150
        stats['speed'] = 25
        stats['defense'] = 25
        stats['sword skill'] = 25
        stats['element skill'] = 25
        stats['intelligence'] = 60
    elif difficulty ==2:
        stats['max health'] = 200
        stats['speed'] = 40
        stats['defense'] = 40
        stats['sword skill'] = 40
        stats['element skill'] = 40
        stats['intelligence'] = 80
    elif difficulty ==3:
        stats['max health'] = 250
        stats['speed'] = 50
        stats['defense'] = 50
        stats['sword skill'] = 50
        stats['element skill'] = 50
        stats['intelligence'] = 100
    elif difficulty ==4:
        stats['max health'] = 300
        stats['speed'] = 65
        stats['defense'] = 65
        stats['sword skill'] = 65
        stats['element skill'] = 65
        stats['intelligence'] = 120


class Bandit:
    def __int__(self,health,speed,defense,sword,elementskill,element,drops):
        self.element = element
        self.health = health
        self.speed = speed
        self.defense = defense
        self.sword = sword
        self.elementskill = elementskill
        self.drops = drops
stats['element'] = random.choice(elements)
statgen()
boss=False
while running:
    if boss:
        screen.fill(empty)
        screen.blit(images[3], (750, 400))
        textp = 'you won the game'
        pygameprint(textp, 800, 410, 35)
        for event in pg.event.get():
            if event.type == pg.MOUSEBUTTONDOWN:
                running=False
    pg.display.get_surface()
    if robbed>=3:
        screen.fill(empty)
        pygameprint('game over you lost CLICK TO EXIT', 300, 200,100)
        for event in pg.event.get():
            if event.type == pg.MOUSEBUTTONDOWN:
                running=False
        pg.display.flip()
    for event in pg.event.get():
        if event.type == pg.QUIT:
            running = False
        if event.type == pg.MOUSEBUTTONDOWN and position=='village':
            mx,my=pg.mouse.get_pos()
            if 318 <= mx<= 567 and 822  <=my<=895:
                position='jungle'
            elif 617<=mx<=865 and 817<=my<=896:
                position='shop'
            elif 914<=mx<=1160 and 812<=my<=893:
                position='train'
            elif 1212<=mx<=1460 and 819<=my<=895:
                running = False
        if event.type== pg.KEYDOWN:
            if event.key== pg.K_ESCAPE:
                running=False
    if position=='village':
        village()
    elif position=='jungle':
        jungle()
    elif position=='shop':
        shop()
    elif position=='train':
        train()
    ui()

    pg.display.flip()

    clock.tick(60)  # limits FPS to 60

